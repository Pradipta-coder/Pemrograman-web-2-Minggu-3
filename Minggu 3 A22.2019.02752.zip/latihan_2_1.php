<h2>Nomor 1 </h2>
<?php

for ($i = 1; $i <= 5; $i++) {
    for ($k = 1; $k <= $i; $k++) {
        echo "$i ";
    }

    echo "<br>";
}
