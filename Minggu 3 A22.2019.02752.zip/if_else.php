<?php
$nilai = 50;if ($nilai >= 60) { 
echo "Nilai Anda $nilai, Anda LULUS";
} else { 
echo "Nilai Anda $nilai, Anda GAGAL";
}
?> 