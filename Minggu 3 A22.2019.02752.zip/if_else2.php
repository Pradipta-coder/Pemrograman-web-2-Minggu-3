<?php
$user = "dipta";
$pass = "123"
if ($user == "dipta" && $pass == "123") {
echo "Login Berhasil";
} else {
echo "Login Gagal";
}
?>